#by JK Hacker
หลังจากติดตั้งเสร็จ

$ cd spammer-grab
$ npm install

คำสั่งใช้
npm run start

คำสั่งใช้งาน
release

เอ็นเตอร์
